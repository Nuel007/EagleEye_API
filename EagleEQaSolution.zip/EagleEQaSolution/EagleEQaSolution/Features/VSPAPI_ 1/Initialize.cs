﻿using System.Reflection.Metadata.Ecma335;
using TechTalk.SpecFlow;

namespace EagleEQaSolution.Features.API
    //I would create a Helper class for this process 
{
   ///<summary>
   ///this class is created by manny to initialize all mandatory commonVariables
   /// 
   /// </summary>
   /// 

    internal class Initialize
    {
        private static object Log;

        public static void InitializeApiCommonVariable()
        {
           // Log.Logger($"Initializing Api variable and settings...");

            //I would create a Log class in the helper class to log time stamps/dates etc for the API

        }

    }
}
﻿using TechTalk.SpecFlow;

namespace EagleEQaSolution.Features.API
{
    ///<summary>
    ///common variables to store value
    /// Author:Manny 
    /// </summary>
    /// 
    public class CommonVariable
    {
        #region variables
        //=======================general variable=======================
        public static string BaseUrl { get; set; }

        //==============I can set my Jenkins machine here===================

        //================I can also set a file path here==================

        #endregion variables
    }

}
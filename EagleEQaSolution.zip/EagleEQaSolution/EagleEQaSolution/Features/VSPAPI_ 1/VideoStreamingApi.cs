﻿using Newtonsoft.Json;
using System.Runtime.CompilerServices;
using TechTalk.SpecFlow;

namespace EagleEQaSolution.Features.API
{
    [Binding]
     class VideoStreamingApi
    {
        private static object userTypeFree;
        private static object userType;
        private static object unknownUserType;
        #region properties
        //  private static IRestResponse VideoStreamingResp { get; set; }

        public static string RequestType { get; set; }
        public static object VideoStreamingResp { get; private set; }

        //Create a restsharp class to handle this error
        #endregion properties

        public static void VideoStreaming(string req)
        {
            //RestRequest Streaming = new RestRequest(url, Method.GET, DataFormat.Json);
            //Again creating a restSharp class would handle these errors

        }
        //var reqContent = JsonConvert.SerializeObject(requestJson);
        #region response
        
        //public static string VideoStreamingResponse()
        //{
        //    int statusCode = (int)VideoStreamingResp.StatusCode;
        //    if (statusCode == 200)
        //        userType = userTypeFree;

        //    else
        //        userType = unknownUserType;
        //}
        #endregion response
    }
}
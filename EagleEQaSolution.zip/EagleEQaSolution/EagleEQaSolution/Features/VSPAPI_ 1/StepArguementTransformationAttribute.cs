﻿using System;

namespace EagleEQaSolution.Features.API
{
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = true)]
    public class StepArgumentTransofmationAttribute : Attribute
    {
        public string Regex { get; set; }

        public StepArgumentTransofmationAttribute (string regex)
        {
            Regex = regex;
        }
        public StepArgumentTransofmationAttribute()
        {
            Regex = null;
        }
    }
}
﻿using System.Configuration;
using TechTalk.SpecFlow;

namespace EagleEQaSolution.Features.API
{
    [Binding]
    public sealed class BaseApiSteps
    {
        [Given(@"I create Rest User using base URL""(.*)""")]
        public void GivenICreateRestUserUsingBaseUrl(string baseURL)
        {
            Dictionary<string, string> urlDict = new Dictionary<string, string>()
            {
                {"AuthorizationUrl", Settings.Default.AuthorizationUrl },
                //We can declare more base urls here for future use

            };
            if (!urlDict.ContainsKey(baseURL))
                urlDict.Add(baseURL, baseURL);
            var url = urlDict[baseURL];
            CommonVariable.BaseUrl = url;
            Initialize.InitializeApiCommonVariable();
        }
    }
}
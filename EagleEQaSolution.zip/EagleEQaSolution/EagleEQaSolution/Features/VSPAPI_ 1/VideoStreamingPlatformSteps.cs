﻿using System.Runtime.InteropServices;
using TechTalk.SpecFlow;

namespace EagleEQaSolution.Features.API
{
    public class InputField
    {
        public string FieldType { get; set; }
        public string FieldName { get; set; }
        public string FieldValue { get; set; }
    }

    [Binding]
    public sealed class VideoStreamingPlatformSteps
    {
        public object Assert { get; private set; }

        [StepArgumentTransformation]
        public IEnumerable<InputField> InputTransform(Table table)
        {
            return table.Rows.Select(r => new InputField()
            {
                FieldType = r[0],
                FieldName = r[1],
                FieldValue = r[2],
            });
        }

        [When(@"I send ""(.*)"" request ""(.*)""  for Video Streaming")]
        public void WhenISendRequestForVideoStreaming(string requestType, string req, IEnumerable<InputField> fields)
        {
            VideoStreamingApi.RequestType = requestType;
            foreach (var row in fields)
            {
                var fieldType = row.FieldType; //row[0]
                var fieldName = row.FieldName; //row[1]
                var fieldValue = row.FieldValue; //row[2]

                switch (fieldName)
                {
                    case "Content-Type ":
                    case "CMG-AccessToken ":
                        break;

                    case "UserType":
                        req = req.Replace("{UserType}", fieldValue);
                        break;

                    case "name":
                        req = req.Replace("{name}", fieldValue);
                        break;

                    case "content":
                        req = req.Replace("{content}", fieldValue);
                        break;

                }
            }
        }

        [Then(@"I see the response ""([^""]*)"" from server for Video Streaming")]
        public void ThenISeeTheResponseFromServerForVideoStreaming(string status)
        {
            VideoStreamingApi.VideoStreamingGetRequest("https://a8e38tulbj.execute-api.eu-west-2.amazonaws.com/api/playlists/free");
            Assert.AreEqual(status, VideoStreamingApi.VideoStreamingResponse());
            //Create Assert Equality.cs to handle assertions
            //Create VideoStreamingResponse
            //create a Json class to handle deserialization of HTML
            //I havent done the above to save time and my disk space
        }

    }
}
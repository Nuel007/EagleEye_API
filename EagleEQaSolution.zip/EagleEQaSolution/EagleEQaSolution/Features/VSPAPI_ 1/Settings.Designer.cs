﻿using TechTalk.SpecFlow;

namespace EagleEQaSolution.Features.API
{
    internal sealed partial class Settings : global::System.Configuration.ApplicationSettingsBase
    {
        private static Settings defaultInstance = ((Settings)(global::System.Configuration.ApplicationSettingsBase.Synchronized(new Settings())));

        public static Settings Default
        {
            get
            {
                return defaultInstance;
            }
        }

        [global::System.Configuration.UserScopedSettingAttribute()]
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.Configuration.DefaultSettingValueAttribute("chrome")]

        public string Browser
        {
            get
            {
                return ((string)(this["Browser"]));
            }
            set
            {
                this["Browser"] = value;
            }
        }

        [global::System.Configuration.UserScopedSettingAttribute()]
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.Configuration.DefaultSettingValueAttribute("https://a8e38tulbj.execute-api.eeu-west-2.amazonaws.com/api/plalist/:usertype")]
        public string AuthorizationUrl
        {
            get
            {
                return ((string)(this["AuthorizationUrl"]));
            }
        }
    }

}
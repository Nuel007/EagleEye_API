﻿using System.Net.Http;
using TechTalk.SpecFlow;
using NUnit.Framework;

namespace EagleEQaSolution.Features.VSPAPI
{
    [Binding]
    public class VSPEasyApproachStepsDefinition
    {
        //private const string BASE_URL = "https://a8e38tulbj.execute-api.eu-west-2.amazonaws.com/api/playlists/{userType}";
        private HttpClient client;
        private HttpResponseMessage response;

        public object Assert { get; private set; }

        [Given(@"a (.*) user makes a request to the playlists API")]
        public void GivenAUserMakesARequestToThePlaylistsAPI(string userType)
        {
            // I Set up HTTP client and make the API request based on the userType
            client = new HttpClient();
            response = client.GetAsync($"https://a8e38tulbj.execute-api.eu-west-2.amazonaws.com/api/playlists/{userType}").Result;
        }

        [When(@"the response is received")]
        public void WhenTheResponseIsReceived()
        {
            // response has already been obtained
            //I can also create a series of method if I need to validate the response received
            //I would serialize and deserialize these
            //var content = HandleContent.getContent<UserType>(response);
            //Assert.AreEqual(UserType.userType, content.usertype);
            //var api = new api<HttpResponseMessage>();
            //response = api.responseMessage();
        }

        [Then(@"the playlists API response should include the ""Included with Premium"" playlist")]
        public void ThenThePlaylistsAPIResponseShouldIncludeThePlaylist()
        {
            // Parse the response and assert that it includes the "Included with Premium" playlist

            var responseBody = response.Content.ReadAsStringAsync().Result;
            Assert.IsTrue(responseBody.Contains("Included with Premium"));
        }

        [Then(@"the playlists API response should not include the ""Included with Premium"" playlist")]
        public void ThenThePlaylistsAPIResponseShouldNotIncludeThePlaylist()
        {
            var responseBody = response.Content.ReadAsStringAsync().Result;
            Assert.IsFalse(responseBody.Contains("Included with Premium"));
        }

        [Then(@"the response status code should be (\d+)")]
        public void ThenTheResponseStatusCodeShouldBe(int expectedStatusCode)
        {
            // status code assertion
            Assert.AreEqual(expectedStatusCode, (int)response.StatusCode);
        }

        [Then(@"the response should contain the message ""(.*)""")]
        public void ThenTheResponseShouldContainTheMessage(string expectedMessage)
        {
            // to assert that response contains the expected message
            var responseBody = response.Content.ReadAsStringAsync().Result;
            Assert.IsTrue(responseBody.Contains(expectedMessage));
        }
    }
}
